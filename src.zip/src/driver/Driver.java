package driver;

import java.util.Random;
import java.util.Scanner;

import children.Addition;
import children.Division;
import children.Multiplication;
import children.Power;
import children.Subtraction;
import parent.Question;

public class Driver {

	public static void main(String[] args) 
	{
		Question[] questionArray = {new Addition(), new Subtraction(), new Multiplication(), new Division(), new Power()};
		Random myRand = new Random();
		Scanner userInput = new Scanner(System.in);
		int[] highScores = new int[6];
		int tempScore = 0; 
		String keepPlaying;
		
		do 
		{
			tempScore = 0;
			System.out.println("Welcome to another round of The Math Game!");
			System.out.println("Do your best!");
			for (int i = 0; i<5; i++) 
			{
				int index = myRand.nextInt(5);
				questionArray[index].getQuestion();
				double answer = Double.parseDouble(userInput.next());
				if (questionArray[index].checkAnswer(answer)) 
				{
					tempScore++;
					System.out.println("Correct!");
				} 
				else 
				{
					System.out.println("Wrong...");
				}
			}
			highScores[5] = tempScore;
			selectionSort(highScores);
			System.out.println();
			System.out.println("High Scores:");
			for (int i=0; i < 5; i++) {
				System.out.println((i + 1) + ". " + highScores[i]);
			}
			System.out.println();
			System.out.println("Would you like to play another round? (y/n)");
			keepPlaying = userInput.next();
	
			
		} while(keepPlaying.equalsIgnoreCase("y"));
	}
	
	public static void selectionSort (int[] list) 
	{ 
		int min;
		int temp;
		for (int index = 0; index < list.length- 1; index++)
		{ 
			min = index; 
			for (int scan = index+ 1;scan < list. length; scan++)
				if (list[scan] > list[min])
					min = scan; 
			
				temp = list[ min];
				list[min] = list[index];
				list[index] = temp; 
		} 
	} 
}
