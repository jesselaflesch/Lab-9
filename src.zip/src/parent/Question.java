package parent;

import java.util.Random;

public abstract class Question 
{
	protected int operand1, operand2;
	protected double actualAnswer;
	protected Random myRand = new Random();
	protected double tolerance = .1;
	
//Print out own question
	public abstract void getQuestion();
	
//Print out actual answer to question
	protected abstract void getActualAnswer();
	
//Check answer.
	public boolean checkAnswer(double userAnswer)
	{
		return ((Math.abs(userAnswer - actualAnswer) <= tolerance));
	}

}
