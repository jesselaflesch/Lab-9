package children;

import parent.Question;

public class Division extends Question
{
	public Division() 
	{
		
	}
	
	public void getQuestion() {
		this.operand1 = myRand.nextInt(10)+1;
		this.operand2 = myRand.nextInt(10)+1;
		System.out.println("What is " + operand1 + " / " + operand2 + " ?");
		getActualAnswer();
	}

	protected void getActualAnswer() {
		this.actualAnswer = ((double) operand1) / ((double) operand2);
	}
}
