package children;

import parent.Question;

public class Subtraction extends Question
{
	public Subtraction() 
	{
		
	}
	
	public void getQuestion() {
		this.operand1 = myRand.nextInt(10)+1;
		this.operand2 = myRand.nextInt(operand1)+1;
		System.out.println("What is " + operand1 + " - " + operand2 + " ?");
		getActualAnswer();
	}

	protected void getActualAnswer() {
		this.actualAnswer = (double) (operand1 - operand2);
	}
}
