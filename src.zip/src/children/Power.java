package children;

import parent.Question;

public class Power extends Question
{
	public Power() 
	{
		
	}
	
	public void getQuestion() {
		this.operand1 = myRand.nextInt(10)+1;
		this.operand2 = myRand.nextInt(5)+1;
		System.out.println("What is " + operand1 + " raised to the power of  " + operand2 + " ?");
		getActualAnswer();
	}

	protected void getActualAnswer() {
		this.actualAnswer = Math.pow((double) operand1, (double) operand2);
	}
}
