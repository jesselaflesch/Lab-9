package children;

import parent.Question;

public class Multiplication extends Question
{
	public Multiplication() 
	{
		
	}
	
	public void getQuestion() {
		this.operand1 = myRand.nextInt(10)+1;
		this.operand2 = myRand.nextInt(10)+1;
		System.out.println("What is " + operand1 + " x " + operand2 + " ?");
		getActualAnswer();
	}

	protected void getActualAnswer() {
		this.actualAnswer = (double) operand1 * operand2;
	}
}
