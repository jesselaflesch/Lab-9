package children;

import parent.Question;

public class Addition extends Question
{
	
	public Addition() 
	{
		
	}
	
	public void getQuestion() {
		this.operand1 = myRand.nextInt(10)+1;
		this.operand2 = myRand.nextInt(10)+1;
		System.out.println("What is " + operand1 + " + " + operand2 + " ?");
		getActualAnswer();
	}

	protected void getActualAnswer() {
		this.actualAnswer = (double) operand1 + operand2;
	}

}
