import java.util.Random;

//****************************************************************************************
// Author: Ian Gonzales											     File: MathGame.java 
// Partner: Jesse LaFlesch                              Last Changed Date: 9 February 2018
// Purpose: Represents a MathGame object that generates random math random math questions 
//          and compares the actual answer to the user's answer.
// Jesse took problems 1 and 2, I took 4 and 5. We then finalized all 4 together. 
//****************************************************************************************

public class MathGame 
{

	private double randomNumber1, randomNumber2, actualAnswer;
	private short randomOperator;
	Random numRand = new Random();

	//--------------------------------------------------------------------
	// Sets up an instance of a MathGame.
	//--------------------------------------------------------------------
	public MathGame() 
	{
	
	}
	
	//--------------------------------------------------------------------
	// Generates a random math question involving two numbers and returns
	// it as a string. 
	//--------------------------------------------------------------------
	public String generateQuestion() 
	{
		this.randomNumber1 = (double) (numRand.nextInt(10) + 1);
		this.randomNumber2 = (double) (numRand.nextInt(10) + 1);
		this.randomOperator = (short) (numRand.nextInt(4));
		if (randomOperator == 0)
			return "What is " + randomNumber1 + " + " + randomNumber2 + " ?";
		else if (randomOperator == 1)
			return "What is " + randomNumber1 + " - " + randomNumber2 + " ?";
		else if (randomOperator == 2)
			return "What is " + randomNumber1 + " x " + randomNumber2 + " ?";
		else if (randomOperator == 3)
			return "What is " + randomNumber1 + " / " + randomNumber2 + " ?";
		return "";
	
	}
	

	//--------------------------------------------------------------------
	// Get's the actual answer to the question made by .generateQuestion
	//--------------------------------------------------------------------
	public double getActualAnswer() 
	{
		if (randomOperator == 0) 
		{
			actualAnswer = randomNumber1 + randomNumber2;
			return randomNumber1 + randomNumber2;
		}
		if (randomOperator == 1) 
		{
			actualAnswer = randomNumber1 - randomNumber2;
			return randomNumber1 - randomNumber2;
		}
		if (randomOperator == 2) 
		{
			actualAnswer = randomNumber1 * randomNumber2;
			return randomNumber1 * randomNumber2;
		}
		if (randomOperator == 3) 
		{
			actualAnswer = randomNumber1 / randomNumber2;
			return randomNumber1 / randomNumber2;
		}
		else
			return 0.00;
	}
	
	
	//--------------------------------------------------------------------
	// Compares the user answer to the actual answer and returns the 
	// boolean True or False.
	//--------------------------------------------------------------------
	public boolean checkAnswer(double userAnswer) 
	{
		if (Math.abs(userAnswer - actualAnswer) < .01)
			return true;
		else 
			return false;
	
	}
}
