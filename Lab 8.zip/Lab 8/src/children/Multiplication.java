package children;

import parent.Question;

public class Multiplication extends Question
{

}
