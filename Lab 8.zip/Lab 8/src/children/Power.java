package children;

import parent.Question;

public class Power extends Question
{

}
