package children;

import parent.Question;

public class Subtraction extends Question
{

}
