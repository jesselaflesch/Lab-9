package children;

import parent.Question;

public class Addition extends Question
{

}
