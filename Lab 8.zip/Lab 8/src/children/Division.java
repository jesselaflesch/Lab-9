package children;

import parent.Question;

public class Division extends Question
{

}
