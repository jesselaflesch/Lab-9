import java.text.DecimalFormat;
import java.util.Scanner;
import java.text.DecimalFormat;

//****************************************************************************************
// Author: Ian Gonzales											     File: Problem5.java 
// Partner: Jesse LaFlesch                              Last Changed Date: 9 February 2018
// Purpose: To generate random math questions and see if the user can get them right.
// Jesse took problems 1 and 2, I took 4 and 5. We then finalized all 4 together. 
//****************************************************************************************

public class Problem5 {
	
	public static void main(String[] args) {
		
		double userAnswer;
		DecimalFormat answerFormat = new DecimalFormat("0.##");
		
		// Creating Scanner and MathGame instances to play the game //
		Scanner userInput = new Scanner(System.in);
		MathGame myGame = new MathGame();
		
		// Greeting the user and explaining input //
		System.out.println("Welcome to the math game! Answer the following questions as best as you can.\n"
				+ "Remember to truncate your answer to the hundreth's place.\n"
				+ "Example: \"2.66666\" is entered as \"2.66\"\n");
		
		// Generating a question, getting the user input, then checking their answer //
		System.out.println(myGame.generateQuestion());
		userAnswer = userInput.nextDouble();
		System.out.println();
		System.out.println("Your answer was " + userAnswer + ", the actual answer was " + answerFormat.format(myGame.getActualAnswer()));
		if (myGame.checkAnswer(userAnswer))
			System.out.println("You got it right!");
		else
			System.out.println("You got it wrong, but keep trying!");
		
		// Generating another question, getting the user input, then checking their answer //
		System.out.println(myGame.generateQuestion());
		userAnswer = userInput.nextDouble();
		System.out.println();
		System.out.println("Your answer was " + userAnswer + ", the actual answer was " + answerFormat.format(myGame.getActualAnswer()));
		if (myGame.checkAnswer(userAnswer))
			System.out.println("You got it right!");
		else
			System.out.println("You got it wrong, but keep trying!");
		
		// Generating the final question, getting the user input, then checking their answer //
		System.out.println(myGame.generateQuestion());
		userAnswer = userInput.nextDouble();
		System.out.println();
		System.out.println("Your answer was " + userAnswer + ", the actual answer was " + answerFormat.format(myGame.getActualAnswer()));
		if (myGame.checkAnswer(userAnswer))
			System.out.println("You got it right!\n");
		else
			System.out.println("You got it wrong, but keep trying!\n");

		
		
	}

}
