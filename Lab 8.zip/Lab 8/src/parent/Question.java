package parent;

public abstract class Question 
{
	protected int operand1, operand2;
	protected int actualAnswer;
	
//Print out own question
	public abstract void getQuestion();
	
//Print out actual answer to question
	public abstract void getActualAnswer();
	
//Check answer.
	public void checkAnswer(int userAnswer)
	{
		
	}
	
	public void checkAnswer(double userAnswer)
	{
		
	}
	
	
	
}
