package driver;

import children.Addition;
import children.Division;
import children.Multiplication;
import children.Power;
import children.Subtraction;
import parent.Question;

public class Driver {

	public static void main(String[] args) 
	{
		Question[] questionArray = {new Addition(), new Subtraction(), new Multiplication(), new Division(), new Power()};
		

	}

}
